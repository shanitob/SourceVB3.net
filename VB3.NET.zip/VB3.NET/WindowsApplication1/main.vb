﻿Public Class frmmain

    Private Sub tslbl1_Click(sender As Object, e As EventArgs) Handles tslbl1.Click
        frmsanpham.Show()

    End Sub

    Private Sub tslblkh_Click(sender As Object, e As EventArgs) Handles tslblkh.Click
        frmkhachhang.Show()
    End Sub

    Private Sub frmmain_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class
